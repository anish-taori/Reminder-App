import 'package:flutter/material.dart';
import 'package:reminder_app/data/tasks_list.dart';

class CompletedTasksScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    final completedTaskList = tasksList.where((element) => element.completed==true).toList();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey,
        title: Text(
          'Completed Tasks',
          style: TextStyle(
            fontSize: 30,
            foreground: Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = 2
              ..color = Colors.blue[700]!,
          ),
        ),
      ),
      body: ListView.builder(
        itemCount: completedTaskList.length,
        itemBuilder: (context,i){
            return ListTile(
              tileColor: Colors.green,
              title: Row(
                  children: [
                    Text(completedTaskList[i].taskName),
                    Text("     "),
                    Text(completedTaskList[i].taskTime),
                  ]
              ),
            );
        },
      ),
    );
  }
}
