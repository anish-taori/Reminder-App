import 'package:flutter/material.dart';
import 'package:reminder_app/models/task.dart';
import 'package:reminder_app/data/tasks_list.dart';
import 'package:reminder_app/screens/completed_tasks_screen.dart';

class TasksScreen extends StatefulWidget {

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  final myController = TextEditingController();
  final myController2 = TextEditingController();
  @override
  void dispose() {
    myController.dispose();
    myController2.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.grey,
        title: Text(
          'My Tasks',
          style: TextStyle(
            fontSize: 30,
            foreground: Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = 2
              ..color = Colors.blue[700]!,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: (){
              final String time;
              final String taskName;
              showModalBottomSheet<void>(
                  context: context,
                  builder: (BuildContext context) {
                    return Container(
                      height: 300,
                      color: Colors.blue,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            const Text('Please enter a new task'),
                            TextField(
                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                labelText: 'Task Name',
                              ),
                              controller: myController,
                            ),
                            TextField(
                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                labelText: 'Time',
                              ),
                              controller: myController2,
                            ),
                            ElevatedButton(
                              child: const Text('Add'),
                              onPressed: (){
                                setState(() {
                                  Task newTask = Task(taskName: myController.text,taskTime: myController2.text);
                                  tasksList.add(newTask);
                                  Navigator.pop(context);
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                    );
                  }
              );
            },
          )
        ],
      ),
      body: ListView.builder(
          itemBuilder: (BuildContext context,int i){
            Task newTask = tasksList[i];
            return ListTile(
              title: Row(
                children: [
                  Text(newTask.taskName,style: TextStyle(),),
                  Text("     "),
                  Text(newTask.taskTime),
                ]
              ),
              leading: Checkbox(
                value: newTask.completed,
                onChanged: (bool? value) {
                  setState(() {
                    newTask.completed = value!;
                  });
                  if(value == true){
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => CompletedTasksScreen()),
                    );
                  }
                },
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(Icons.edit),
                    onPressed: (){
                      showModalBottomSheet<void>(
                          context: context,
                          builder: (BuildContext context) {
                            return Container(
                              height: 300,
                              color: Colors.amber,
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    const Text('Please edit the task'),
                                    TextField(
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(),
                                        labelText: 'Task Name',
                                      ),
                                      controller: myController,
                                    ),
                                    TextField(
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(),
                                        labelText: 'Time',
                                      ),
                                      controller: myController2,
                                    ),
                                    ElevatedButton(
                                      child: const Text('Edit'),
                                      onPressed: (){
                                        setState(() {
                                          Task editedTask = Task(taskName: myController.text,taskTime: myController2.text);
                                          tasksList.add(editedTask);
                                          tasksList.remove(newTask);
                                          Navigator.pop(context);
                                        });
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }
                      );

                    },
                  ),
                  IconButton(
                    icon: Icon(Icons.delete),
                    onPressed: (){
                      setState(() {
                        tasksList.remove(newTask);
                      });
                    },
                  ),
                ],
              ),
              tileColor: Colors.orange,
            );
          },
        itemCount: tasksList.length,
          ),
    );
  }
}


