import 'package:reminder_app/models/task.dart';

List<Task> tasksList = [
  Task(taskName: 'Study',taskTime: '12:00 pm',completed: false),
  Task(taskName: 'Play',taskTime: '6:00 pm'),
];